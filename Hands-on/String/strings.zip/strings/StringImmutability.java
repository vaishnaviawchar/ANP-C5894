package com.String.sample;
//Write a Java Program to prove that strings are immutable in java.

//importing Scanner class 
import java.util.Scanner;

//Creating class with a name StringImmutability 
public class StringImmutability 
{
	public static void main(String[] args) 
	{
		 // Creating a string
        String str1 = "Hello";

      

        // Attempting to modify str1
        str1 = " World";

        // Printing the values of str1 and str2
        System.out.println("str1: " + str1);
       
    }

        
}


