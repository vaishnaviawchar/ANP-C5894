package com.hibernate.studentManagement.Dao;

public interface StudentDao 
{
	abstract public void addStudent();
	public void deleteStudent();
	public void editStudent();
	public void displayStudent();
}
