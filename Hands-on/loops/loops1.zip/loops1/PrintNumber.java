package loops;
//print numbers from 1 to 10
public class PrintNumber 
{
	public static void main(String[] args) 
	{
		//c initialized to 1
		int c = 1;
		//condition to check c is less than equal to 10
		while(c<=10)
		{
			System.out.println("Number is: " +c);
			c++;
		}
				
	}

}
