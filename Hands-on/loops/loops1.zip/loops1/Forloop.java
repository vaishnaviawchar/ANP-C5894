package loops;
//simple for loop program
public class Forloop 
{
	public static void main(String[] args)
	{
		for(int i=9;i>0;i--)
		{
			System.out.println("Values of i is :"+ i);
		}

	}
}