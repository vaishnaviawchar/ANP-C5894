package loops;

public class DoWhileLoop {

	public static void main(String[] args) 
	{
		//initializing i to 1
		int i = 1;
		do
		{
			//print hello world
			System.out.println("Hello World");
			i++;
		}
		//test expression
		while(i<6);
	}

}
