package loops;
//simple WhileLoop program
public class WhileLoop 
{
	public static void main(String[] args) 
	{
		//Initialized x to 10
		int x = 10;
		//condition
		while(x<20)
		{
			System.out.println("value of x:" +x);
			x++;
		}
			

	}

}
