package com.Spring.demo.services;

import com.Spring.demo.entity.Login;

public interface LoginServices 
{
	public Login loginUser(String userName, String password);

}
