package com.SpringEmployee.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeBackendProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
