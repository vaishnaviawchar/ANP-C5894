package com.spring.demo;

public interface HotDrinks 
{
	public void prepareHotDrinks();

}
