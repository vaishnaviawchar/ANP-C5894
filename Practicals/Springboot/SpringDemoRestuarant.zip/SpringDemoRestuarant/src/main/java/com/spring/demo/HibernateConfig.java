package com.spring.demo;

public class HibernateConfig {

}
