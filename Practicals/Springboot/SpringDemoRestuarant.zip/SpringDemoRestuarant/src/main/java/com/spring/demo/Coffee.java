package com.spring.demo;

public class Coffee implements HotDrinks
{

	@Override
	public void prepareHotDrinks() 
	{
		System.out.println("Dear Customer, we are preparing a coffee");
		
	}
	

}
