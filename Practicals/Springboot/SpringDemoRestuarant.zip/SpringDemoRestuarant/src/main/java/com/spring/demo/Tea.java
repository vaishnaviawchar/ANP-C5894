package com.spring.demo;

public class Tea implements HotDrinks
{

	@Override
	public void prepareHotDrinks() 
	{
		System.out.println("Dear Customer, we are preparing a tea");
		
	}

}
