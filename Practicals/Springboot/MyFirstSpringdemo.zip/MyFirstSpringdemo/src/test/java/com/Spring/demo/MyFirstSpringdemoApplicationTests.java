package com.Spring.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
