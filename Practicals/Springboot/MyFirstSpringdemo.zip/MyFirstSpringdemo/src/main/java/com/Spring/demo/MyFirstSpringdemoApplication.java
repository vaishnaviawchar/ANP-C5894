package com.Spring.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstSpringdemoApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(MyFirstSpringdemoApplication.class, args);
	}

}
