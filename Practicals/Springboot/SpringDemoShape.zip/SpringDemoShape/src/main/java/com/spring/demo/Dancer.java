package com.spring.demo;

public class Dancer implements Performer
{

	@Override
	public void performer() 
	{
		System.out.println("Dancer is dancing kathak");
		
	}

}
