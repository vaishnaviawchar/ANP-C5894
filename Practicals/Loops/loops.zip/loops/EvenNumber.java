package loops;
////print sum of even numbers from 1 to 100
public class EvenNumber 
{
	public static void main(String[] args) 
	{
		//num initialized to 1
		int num = 1;
		int sum = 0;
		while(num<=100)
		{
			if(num % 2 == 0)
			{
				sum+=0;
			}
			num++;
		}
		System.out.println("Sum of even numbers: " +num);
	}

}
