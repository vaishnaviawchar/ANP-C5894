package com.junit.demo;

public class Calculator 
{ 
	 public int add(int a, int b) 
	 {
		 
		 int result=a+b;
		 return result; //System.out.println(result);
		 }

}
