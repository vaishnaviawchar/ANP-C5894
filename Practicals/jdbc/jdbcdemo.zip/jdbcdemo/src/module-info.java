/**
 * 
 */
/**
 * 
 */
module jdbcdemo {
	requires java.sql;
}