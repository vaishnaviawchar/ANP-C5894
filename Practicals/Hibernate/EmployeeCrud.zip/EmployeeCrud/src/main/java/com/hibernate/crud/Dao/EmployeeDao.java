package com.hibernate.crud.Dao;
//Data access object
public interface EmployeeDao 
{
	abstract public void addEmp();
	public void deleteEmp();
	public void editEmp();
	public void displayEmp();
	

}
